from torch.utils.tensorboard import SummaryWriter
import os

"""
在不同weights上，进行手动测试500/3500/6500/9500/12500/15500/18500
结果如下
4951  5599 12032       RPs/Img: 434.78 IOU: 48.44%     Recall:46.53%

4951  9695 12032       RPs/Img: 44.08  IOU: 59.99%     Recall:80.58%

4951  9749 12032       RPs/Img: 24.46  IOU: 61.59%     Recall:81.03%

4951 10720 12032       RPs/Img: 58.96  IOU: 65.82%     Recall:89.10%

4951 10848 12032       RPs/Img: 53.15  IOU: 66.22%     Recall:90.16%

4951 10602 12032       RPs/Img: 21.31  IOU: 66.50%     Recall:88.12%

4951 10852 12032       RPs/Img: 28.41  IOU: 67.96%     Recall:90.19%
"""
#log_dir = os.path.join('Desktop', '新建文件夹')
# "C:\Users\Eve\Desktop\新建文件夹"
log_dir = "新建文件夹"
iou_writer = SummaryWriter(log_dir=log_dir)
epoch = 0
for i in [48.44,59.99,61.59,65.82,66.22,66.50,67.96]:
    iou_writer.add_scalar('Iou', i, epoch)
    epoch += 1